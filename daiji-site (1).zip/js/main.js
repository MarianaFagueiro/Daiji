/* ==========================================================================
   DAIJI — shared behaviors
   - Nav goes solid on scroll
   - Light/dark theme toggle (persisted in localStorage)
   - Scroll-reveal for .fx-in elements
   - Chatbot widget open/close + placeholder reply
     (swap sendMockReply() for a real API/SDK call when you wire up the bot)
   ========================================================================== */

document.addEventListener('DOMContentLoaded', () => {

  /* ---- theme toggle ---- */
  const root = document.documentElement;
  const THEME_KEY = 'daiji-theme';
  const saved = localStorage.getItem(THEME_KEY);
  if (saved) root.setAttribute('data-theme', saved);

  document.querySelectorAll('[data-theme-toggle]').forEach(btn => {
    btn.addEventListener('click', () => {
      const current = root.getAttribute('data-theme') === 'light' ? 'light' : 'dark';
      const next = current === 'light' ? 'dark' : 'light';
      if (next === 'dark') root.removeAttribute('data-theme');
      else root.setAttribute('data-theme', 'light');
      localStorage.setItem(THEME_KEY, next);
    });
  });

  /* ---- nav solid on scroll ---- */
  const nav = document.getElementById('ouraNav');
  if (nav) {
    const onScroll = () => {
      if (window.scrollY > 60) nav.classList.add('solid');
      else nav.classList.remove('solid');
    };
    window.addEventListener('scroll', onScroll, { passive: true });
    onScroll();
  }

  /* ---- scroll reveal ---- */
  const fx = document.querySelectorAll('.fx-in');
  if ('IntersectionObserver' in window) {
    const io = new IntersectionObserver((entries) => {
      entries.forEach(e => {
        if (e.isIntersecting) { e.target.classList.add('show'); io.unobserve(e.target); }
      });
    }, { threshold: .12 });
    fx.forEach(el => io.observe(el));
  } else {
    fx.forEach(el => el.classList.add('show'));
  }

  /* ---- chatbot widget ---- */
  const chatFab = document.getElementById('chatFab');
  const chatPanel = document.getElementById('chatPanel');
  const chatClose = document.getElementById('chatClose');
  const chatForm = document.getElementById('chatForm');
  const chatInput = document.getElementById('chatInput');
  const chatBody = document.getElementById('chatBody');

  const toggleChat = () => chatPanel && chatPanel.classList.toggle('open');
  if (chatFab) chatFab.addEventListener('click', toggleChat);
  if (chatClose) chatClose.addEventListener('click', toggleChat);

  if (chatForm) {
    chatForm.addEventListener('submit', (e) => {
      e.preventDefault();
      const text = chatInput.value.trim();
      if (!text) return;
      appendBubble(text, 'user');
      chatInput.value = '';
      // TODO: replace sendMockReply() with a real call to your chatbot
      // backend / SDK (e.g. Dialogflow, Telegram Bot API, a custom
      // Daiji endpoint, etc). This mock just echoes a canned response.
      setTimeout(() => sendMockReply(text), 500);
    });
  }

  function appendBubble(text, who) {
    if (!chatBody) return;
    const div = document.createElement('div');
    div.className = 'chat-bubble ' + who;
    div.textContent = text;
    chatBody.appendChild(div);
    chatBody.scrollTop = chatBody.scrollHeight;
  }

  function sendMockReply(userText) {
    appendBubble(
      'Isso aqui é só um espaço reservado — conecte este widget ao seu backend de chatbot para responder de verdade. 🙂',
      'bot'
    );
  }

  /* ---- Telegram deep link ---- */
  // Replace 'daiji_bot' with your real bot's @username once it exists
  // (create one via https://t.me/BotFather). Every "Comece pelo Telegram"
  // button uses this constant so you only change it in one place.
  const TELEGRAM_BOT_USERNAME = 'daiji_bot';
  document.querySelectorAll('[data-telegram-cta]').forEach(btn => {
    btn.href = `https://t.me/${TELEGRAM_BOT_USERNAME}`;
    btn.target = '_blank';
    btn.rel = 'noopener';
  });

  /* ---- booking modal (fully client-side simulation) ---- */
  const bookingModal = document.getElementById('bookingModal');
  if (bookingModal) {
    const bmDoctor = document.getElementById('bmDoctor');
    const bmSpecialty = document.getElementById('bmSpecialty');
    const bmSlots = document.getElementById('bmSlots');
    const bmForm = document.getElementById('bmForm');
    const bmStepPick = document.getElementById('bmStepPick');
    const bmStepConfirm = document.getElementById('bmStepConfirm');
    const bmProtocol = document.getElementById('bmProtocol');
    const bmSummary = document.getElementById('bmSummary');
    let selectedSlot = null;

    const openBooking = (name, specialty) => {
      bmDoctor.textContent = name;
      bmSpecialty.textContent = specialty;
      bmStepPick.style.display = '';
      bmStepConfirm.style.display = 'none';
      selectedSlot = null;
      bmSlots.querySelectorAll('.bm-slot').forEach(s => s.classList.remove('picked'));
      bookingModal.classList.add('open');
    };

    document.querySelectorAll('[data-book]').forEach(btn => {
      btn.addEventListener('click', (e) => {
        e.preventDefault();
        openBooking(btn.dataset.book, btn.dataset.specialty || '');
      });
    });

    document.querySelectorAll('#bookingModal .bm-close, #bookingModal .bm-overlay').forEach(el => {
      el.addEventListener('click', () => bookingModal.classList.remove('open'));
    });

    if (bmSlots) {
      bmSlots.querySelectorAll('.bm-slot').forEach(slot => {
        slot.addEventListener('click', () => {
          bmSlots.querySelectorAll('.bm-slot').forEach(s => s.classList.remove('picked'));
          slot.classList.add('picked');
          selectedSlot = slot.textContent.trim();
        });
      });
    }

    if (bmForm) {
      bmForm.addEventListener('submit', (e) => {
        e.preventDefault();
        if (!selectedSlot) { alert('Escolha um horário disponível.'); return; }
        const protocol = 'DAIJI-' + Math.random().toString(36).slice(2, 8).toUpperCase();

        // Persist locally so a returning visit still shows the booking —
        // this is a front-end simulation; swap for a real API call to your
        // scheduling backend when one exists.
        const bookings = JSON.parse(localStorage.getItem('daiji-bookings') || '[]');
        bookings.push({ protocol, doctor: bmDoctor.textContent, specialty: bmSpecialty.textContent, slot: selectedSlot });
        localStorage.setItem('daiji-bookings', JSON.stringify(bookings));

        bmProtocol.textContent = protocol;
        bmSummary.textContent = `${bmDoctor.textContent} · ${selectedSlot}`;
        bmStepPick.style.display = 'none';
        bmStepConfirm.style.display = '';
      });
    }
  }

  /* ---- score gauge fill (proportional to the example number shown) ---- */
  const scoreFill = document.getElementById('scoreFill');
  const scoreNum = document.getElementById('scoreNum');
  if (scoreFill && scoreNum) {
    const value = parseInt(scoreNum.textContent, 10) || 0;
    const circumference = 2 * Math.PI * 54; // r=54
    const offset = circumference - (value / 100) * circumference;
    requestAnimationFrame(() => { scoreFill.style.strokeDashoffset = offset; });
  }

});
